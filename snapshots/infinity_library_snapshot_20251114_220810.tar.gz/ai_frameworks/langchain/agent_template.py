from langchain.llms import OpenAI

def run():
    llm = OpenAI()
    print("[LangChain] Agent running...")
    print(llm("Hello from LangChain agent template!"))

if __name__ == "__main__":
    run()
