import chromadb

def run():
    client = chromadb.Client()
    print("[VectorDB] Connected to ChromaDB.")
