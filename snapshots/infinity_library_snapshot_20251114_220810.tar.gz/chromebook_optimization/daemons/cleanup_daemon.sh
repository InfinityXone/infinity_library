#!/bin/bash
while true; do
  bash ~/infinity_library/chromebook_optimization/cleanup/cleanup_engine.sh
  sleep 1800
done
