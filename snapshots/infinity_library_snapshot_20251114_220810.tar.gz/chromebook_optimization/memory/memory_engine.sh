#!/bin/bash
echo "[🧠] Cleaning RAM..."
sync && sudo sh -c "echo 1 > /proc/sys/vm/drop_caches"

echo "[🧠] Killing zombie processes..."
sudo kill -9 $(ps -eo stat,pid | awk '$1=="Z"{print $2}') 2>/dev/null

echo "[🧠] Memory sweep complete."
