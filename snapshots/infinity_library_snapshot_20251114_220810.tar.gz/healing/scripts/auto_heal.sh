#!/bin/bash

ROOT=~/infinity_library
LOG="$ROOT/logs/autoheal.log"
BUILDER="$ROOT/builder/infinity_builder.py"

echo "[🩺] Auto-Heal Engine Activated..." | tee -a "$LOG"

# Run validator
bash "$ROOT/healing/validators/validate_system.sh"
VAL=$?

if [ $VAL -ne 0 ]; then
    echo "[⚠️] Validation failed — initiating full rebuild..." | tee -a "$LOG"
    python3 "$BUILDER"
    echo "[🌟] System rebuilt." | tee -a "$LOG"
else
    echo "[💚] System healthy — no action needed." | tee -a "$LOG"
fi
