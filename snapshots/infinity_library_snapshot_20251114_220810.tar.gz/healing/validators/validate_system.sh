#!/bin/bash

ROOT=~/infinity_library
LOG="$ROOT/logs/heal_validate.log"

echo "[🔍] Running system validation..." | tee -a "$LOG"

# Validate schema
if [ ! -f "$ROOT/schema/universe_schema.json" ]; then
    echo "[❌] Missing universe_schema.json" | tee -a "$LOG"
    exit 1
else
    echo "[✔] Schema OK" | tee -a "$LOG"
fi

# Validate modules
if [ ! -d "$ROOT/modules" ]; then
    echo "[❌] Missing modules directory" | tee -a "$LOG"
    exit 1
else
    echo "[✔] Modules OK" | tee -a "$LOG"
fi

echo "[🌟] Validation passed." | tee -a "$LOG"
