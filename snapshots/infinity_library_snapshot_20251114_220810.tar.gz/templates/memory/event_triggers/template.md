# Memory Template: event_triggers
