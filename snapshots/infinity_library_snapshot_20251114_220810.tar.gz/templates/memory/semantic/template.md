# Memory Template: semantic
