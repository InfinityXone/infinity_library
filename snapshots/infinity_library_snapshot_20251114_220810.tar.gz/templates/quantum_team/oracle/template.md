# Quantum Team Template: oracle
