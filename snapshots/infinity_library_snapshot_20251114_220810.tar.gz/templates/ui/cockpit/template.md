# UI Template: cockpit
