# Agent Template: behavior
