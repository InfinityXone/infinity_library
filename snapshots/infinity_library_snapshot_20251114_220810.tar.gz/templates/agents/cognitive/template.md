# Agent Template: cognitive
