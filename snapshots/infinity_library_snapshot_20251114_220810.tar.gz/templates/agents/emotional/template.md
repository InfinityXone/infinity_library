# Agent Template: emotional
