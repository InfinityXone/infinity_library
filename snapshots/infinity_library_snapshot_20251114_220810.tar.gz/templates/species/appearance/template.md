# Species Template: appearance
