# Species Template: relationships
