# Species Template: emotions
