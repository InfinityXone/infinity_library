#!/bin/bash

ROOT=~/infinity_library
TARGET=~/infinity_sync_backup
LOG="$ROOT/google_sync/logs/rsync.log"

mkdir -p "$TARGET"

echo "[💾] Running rsync backup..." | tee -a "$LOG"
rsync -av --delete "$ROOT/" "$TARGET/" | tee -a "$LOG"
