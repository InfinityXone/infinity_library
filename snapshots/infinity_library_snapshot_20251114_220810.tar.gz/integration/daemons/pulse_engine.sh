#!/bin/bash

LOG=~/infinity_library/logs/pulse.log
mkdir -p ~/infinity_library/logs

EMO=$(cat ~/infinity_library/directories/current_emotion 2>/dev/null || echo "unknown")
MEM=$(du -sh ~/infinity_library/agents | awk '{print $1}')
CPU=$(uptime | awk -F'load average:' '{print $2}')

echo "[❤️‍🔥 PULSE — $(date)]" >> $LOG
echo "Emotion: $EMO" >> $LOG
echo "Agent Memory Size: $MEM" >> $LOG
echo "CPU Load: $CPU" >> $LOG
echo "----------------------------------------" >> $LOG
