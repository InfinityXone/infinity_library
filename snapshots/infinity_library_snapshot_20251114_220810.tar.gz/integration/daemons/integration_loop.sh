#!/bin/bash

while true; do
  bash ~/infinity_library/integration/daemons/health_scanner.sh
  bash ~/infinity_library/integration/daemons/pulse_engine.sh
  sleep 120
done
