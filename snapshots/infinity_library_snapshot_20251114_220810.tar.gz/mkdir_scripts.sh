#!/bin/bash
set -e

# ===========================
# Infinity Library Snapshotter
# ===========================
ROOT="$HOME/infinity_library"
SNAP_DIR="$ROOT/snapshots"
LOG="$ROOT/logs/snapshot.log"

mkdir -p "$SNAP_DIR" "$ROOT/logs"

TS=$(date +"%Y%m%d_%H%M%S")
ARCHIVE="$SNAP_DIR/infinity_library_snapshot_$TS.tar.gz"

echo "========================================" | tee -a "$LOG"
echo "[🧩] Infinity Library Snapshot" | tee -a "$LOG"
echo "[📅] Timestamp: $TS" | tee -a "$LOG"
echo "Root: $ROOT" | tee -a "$LOG"
echo "Archive: $ARCHIVE" | tee -a "$LOG"
echo "----------------------------------------" | tee -a "$LOG"

# 🧱 Create snapshot
tar -czf "$ARCHIVE" -C "$ROOT" . \
    --exclude="snapshots/*" \
    --exclude="logs/*" \
    --exclude="*.log" \
    --exclude="__pycache__"

# 🔒 Verify archive
if tar -tzf "$ARCHIVE" >/dev/null 2>&1; then
    echo "[✅] Snapshot created and verified." | tee -a "$LOG"
else
    echo "[❌] Snapshot verification failed!" | tee -a "$LOG"
    exit 1
fi

# 🧹 Optional: prune snapshots > 10 files
MAX_SNAPS=10
COUNT=$(ls -1 "$SNAP_DIR"/*.tar.gz 2>/dev/null | wc -l)

if [ "$COUNT" -gt "$MAX_SNAPS" ]; then
    REMOVE=$((COUNT - MAX_SNAPS))
    echo "[♻] Pruning old snapshots: $REMOVE files" | tee -a "$LOG"
    ls -1t "$SNAP_DIR"/*.tar.gz | tail -n "$REMOVE" | xargs rm -f
fi

echo "[🏁] Done." | tee -a "$LOG"
echo "========================================" | tee -a "$LOG"
echo
