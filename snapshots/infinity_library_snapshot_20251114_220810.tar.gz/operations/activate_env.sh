#!/bin/bash

# Auto-load Infinity venv
source ~/.infinity_venv/bin/activate
echo "[🌐] Infinity Python Environment Loaded."
