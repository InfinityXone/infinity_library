#!/bin/bash

ROOT=~/infinity_library
MOD_DIR="$ROOT/modules"
GEN="$ROOT/generated"
LOG="$ROOT/logs/scaffold.log"

mkdir -p "$GEN"

log() {
  echo "$1" | tee -a "$LOG"
}

log "[🔧] Running Directory Scaffolding Engine..."

for yaml in "$MOD_DIR"/*.yaml; do
  name=$(basename "$yaml" .yaml)
  dir="$ROOT/$name"

  mkdir -p "$dir"
  log "[📁] Created module dir: $dir"

  mkdir -p "$dir/scripts"
  mkdir -p "$dir/config"
  mkdir -p "$dir/docs"
  mkdir -p "$dir/tests"
  mkdir -p "$dir/workflows"

  log "[📄] Standard directories added for $name"
done

log "[🌟] Directory scaffolding complete."
