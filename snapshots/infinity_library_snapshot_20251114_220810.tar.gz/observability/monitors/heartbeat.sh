#!/bin/bash

ROOT=~/infinity_library
LOG="$ROOT/logs/heartbeat.log"
DATE=$(date)

echo "[❤️] Heartbeat OK — $DATE" >> "$LOG"
