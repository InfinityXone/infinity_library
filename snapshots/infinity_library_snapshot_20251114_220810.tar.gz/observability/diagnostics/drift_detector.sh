#!/bin/bash

ROOT=~/infinity_library
HASH_FILE="$ROOT/logs/system_hash.txt"
NEW_HASH=$(find "$ROOT" -type f -exec sha256sum {} \; | sha256sum)

if [ -f "$HASH_FILE" ]; then
    OLD_HASH=$(cat "$HASH_FILE")
    if [ "$OLD_HASH" != "$NEW_HASH" ]; then
        echo "[⚠️] Drift detected at $(date)" >> "$ROOT/logs/drift.log"
    fi
fi

echo "$NEW_HASH" > "$HASH_FILE"
