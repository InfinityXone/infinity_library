#!/usr/bin/env python3
"""
Infinity Library OS — Structured Log Collector
"""

import os, json, datetime

ROOT = os.path.expanduser("~/infinity_library")
LOG_DIR = os.path.join(ROOT, "logs")
EVENT_LOG = os.path.join(LOG_DIR, "events.log")

def log_event(event_type, message, data=None):
    entry = {
        "timestamp": datetime.datetime.now().isoformat(),
        "event_type": event_type,
        "message": message,
        "data": data or {}
    }
    with open(EVENT_LOG, "a") as f:
        f.write(json.dumps(entry) + "\n")

if __name__ == "__main__":
    log_event("system.test", "Structured logging online.")
