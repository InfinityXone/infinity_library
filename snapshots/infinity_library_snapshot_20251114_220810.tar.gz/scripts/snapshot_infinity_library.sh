#!/bin/bash
set -e

ROOT="$HOME/infinity_library"
SNAP_DIR="$ROOT/snapshots"
LOG="$ROOT/logs/snapshot.log"

mkdir -p "$SNAP_DIR" "$ROOT/logs"

TS=$(date +"%Y%m%d_%H%M%S")
ARCHIVE="$SNAP_DIR/infinity_library_snapshot_$TS.tar.gz"

echo "[📦] Creating Infinity Library snapshot..."
echo "[📅] Timestamp: $TS"

tar -czf "$ARCHIVE" \
    --exclude='snapshots/*' \
    --exclude='logs/*' \
    --exclude='*.log' \
    --exclude='__pycache__' \
    -C "$ROOT" .

if tar -tzf "$ARCHIVE" >/dev/null 2>&1; then
    echo "[✅] Snapshot created and verified: $ARCHIVE"
else
    echo "[❌] Snapshot verification failed!"
    exit 1
fi
