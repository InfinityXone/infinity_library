#!/usr/bin/env python3
"""
Infinity Library OS 3.0 — Builder Agent
Reads:
  - universe_schema.json
  - all YAML module packs
Builds:
  - directory scaffolding
  - templates
  - system inventory
"""

import json, yaml, os, datetime

ROOT = os.path.expanduser("~/infinity_library")
SCHEMA = os.path.join(ROOT, "schema", "universe_schema.json")
MODULE_DIR = os.path.join(ROOT, "modules")
LOG_DIR = os.path.join(ROOT, "logs")
BUILD_LOG = os.path.join(LOG_DIR, "builder.log")

def log(msg):
    with open(BUILD_LOG, "a") as f:
        f.write(f"[{datetime.datetime.now()}] {msg}\n")
    print(msg)

def load_schema():
    with open(SCHEMA, "r") as f:
        return json.load(f)

def load_modules():
    modules = {}
    for file in os.listdir(MODULE_DIR):
        if file.endswith(".yaml"):
            path = os.path.join(MODULE_DIR, file)
            with open(path, "r") as f:
                modules[file] = yaml.safe_load(f)
    return modules

def build_directories(schema, modules):
    os.makedirs(os.path.join(ROOT, "generated"), exist_ok=True)
    for name in modules:
        folder = name.replace(".yaml", "")
        path = os.path.join(ROOT, "generated", folder)
        os.makedirs(path, exist_ok=True)
        log(f"[📁] Built module dir: {path}")

def write_inventory(schema, modules):
    inv_path = os.path.join(ROOT, "generated", "system_inventory.md")
    with open(inv_path, "w") as f:
        f.write("# Infinity Library OS — System Inventory\n\n")
        f.write("## Schema Modules\n")
        for key in schema["modules"]:
            f.write(f"- {key}: {schema['modules'][key]}\n")

        f.write("\n## Loaded YAML Modules\n")
        for m in modules:
            f.write(f"- {m}\n")

    log("[📄] System inventory written.")

def build():
    schema = load_schema()
    modules = load_modules()
    log("[🔍] Schema + modules loaded.")
    build_directories(schema, modules)
    write_inventory(schema, modules)
    log("[🌟] Build complete.")

if __name__ == "__main__":
    build()
