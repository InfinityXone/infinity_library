#!/bin/bash

systemctl --user daemon-reload
systemctl --user enable etherverse_optimization.service
systemctl --user enable etherverse_cleanup.service
systemctl --user enable etherverse_memory.service

systemctl --user start etherverse_optimization.service
systemctl --user start etherverse_cleanup.service
systemctl --user start etherverse_memory.service

echo "[🌟] All Etherverse services started."
