class Persona:
    def __init__(self, name, traits, values, voice, goals):
        self.name = name
        self.traits = traits
        self.values = values
        self.voice = voice
        self.goals = goals
    
    def describe(self):
        return {
            "name": self.name,
            "traits": self.traits,
            "values": self.values,
            "voice": self.voice,
            "goals": self.goals
        }
