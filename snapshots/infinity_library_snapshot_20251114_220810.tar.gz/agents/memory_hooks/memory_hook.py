class MemoryHook:
    def __init__(self, memory_store):
        self.memory = memory_store

    def record(self, event, details):
        self.memory.append({"event": event, "details": details})

    def recall(self, query):
        return [m for m in self.memory if query.lower() in m["event"].lower()]
