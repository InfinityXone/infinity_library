#!/bin/bash

LOG=~/infinity_library/integration/logs/health_scanner.log
mkdir -p ~/infinity_library/integration/logs

echo "[⏱] $(date) — Running Global Health Scan..." >> $LOG

# Disk usage check
USAGE=$(df /home | awk 'NR==2{print $5}' | sed 's/%//')
if [ "$USAGE" -gt 85 ]; then
  echo "[⚠️] Disk usage high: $USAGE% — Triggering cleanup." >> $LOG
  bash ~/infinity_library/chromebook_optimization/cleanup/cleanup_engine.sh
fi

# Zombie processes
ZOMBIES=$(ps -eo stat,pid | awk '$1=="Z"{print $2}')
if [ ! -z "$ZOMBIES" ]; then
  echo "[⚠️] Zombies detected. Clearing..." >> $LOG
  sudo kill -9 $ZOMBIES
fi

# Memory pressure
FREE=$(free -m | awk '/Mem:/{print $4}')
if [ "$FREE" -lt 300 ]; then
  echo "[⚠️] Low memory ($FREE MB) — Running memory sweep." >> $LOG
  bash ~/infinity_library/chromebook_optimization/memory/memory_engine.sh
fi

# Venv integrity
if [ ! -d "$VIRTUAL_ENV" ]; then
  echo "[⚠️] Venv missing — Attempting auto-repair..." >> $LOG
  python3 -m venv ~/.infinity_venv
fi

# Agent engine dirs
for d in personas emotional_states cognitive_maps behaviors actions memory_hooks; do
  if [ ! -d ~/infinity_library/agents/$d ]; then
    echo "[⚠️] Missing agent module: $d — Recreating." >> $LOG
    mkdir -p ~/infinity_library/agents/$d
  fi
done

echo "[✔] Scan complete." >> $LOG
