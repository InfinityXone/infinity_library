#!/bin/bash

ROOT=~/infinity_library
SYNC_LOG="$ROOT/google_sync/logs/drive_sync.log"

echo "[🔁] Running Google Drive sync (placeholder)..." | tee -a "$SYNC_LOG"

# User will plug in rclone remote here
echo "[TODO] Configure rclone remote for Drive sync." | tee -a "$SYNC_LOG"
