#!/bin/bash
echo "[🧹] Clearing apt cache..."
sudo apt clean 2>/dev/null

echo "[🧹] Clearing pip cache..."
pip cache purge

echo "[🧹] Cleaning temp files..."
rm -rf ~/.cache/*
rm -rf /tmp/* 2>/dev/null

echo "[🧹] Cleaning logs older than 7 days..."
find ~/infinity_library/logs -type f -mtime +7 -delete

echo "[🧹] Cleanup complete."
