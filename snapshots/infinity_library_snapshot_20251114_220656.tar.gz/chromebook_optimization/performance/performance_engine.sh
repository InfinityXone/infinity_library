#!/bin/bash
echo "[⚡] Optimizing CPU governor (Chromebook-safe)..."
sudo sh -c 'echo "performance" > /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor' 2>/dev/null

echo "[⚡] Optimizing swappiness..."
sudo sysctl vm.swappiness=10

echo "[⚡] Cleaning system caches..."
sync && sudo sh -c "echo 3 > /proc/sys/vm/drop_caches"

echo "[⚡] Performance optimization complete."
