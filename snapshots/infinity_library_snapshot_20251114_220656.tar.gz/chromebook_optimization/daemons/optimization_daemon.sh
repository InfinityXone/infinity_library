#!/bin/bash
while true; do
  bash ~/infinity_library/chromebook_optimization/performance/performance_engine.sh
  sleep 3600
done
