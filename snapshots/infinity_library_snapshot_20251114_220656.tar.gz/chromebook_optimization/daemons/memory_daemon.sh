#!/bin/bash
while true; do
  bash ~/infinity_library/chromebook_optimization/memory/memory_engine.sh
  sleep 1200
done
