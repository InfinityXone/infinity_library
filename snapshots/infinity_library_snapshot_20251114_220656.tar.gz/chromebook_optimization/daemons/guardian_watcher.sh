#!/bin/bash
while true; do
  # Check disk usage
  USAGE=$(df /home | awk 'NR==2{print $5}' | sed 's/%//')
  if [ "$USAGE" -gt 85 ]; then
    echo "[⚠️] Disk usage high ($USAGE%) — triggering cleanup..."
    bash ~/infinity_library/chromebook_optimization/cleanup/cleanup_engine.sh
  fi

  # Check broken venv
  if [ ! -d "$VIRTUAL_ENV" ]; then
    echo "[⚠️] Venv missing — attempting auto-repair..."
    python3 -m venv ~/.infinity_venv
  fi

  # Check for crashed Python jobs
  if pgrep -f "python" >/dev/null; then
    echo "[🧠] Python jobs healthy."
  else
    echo "[⚠️] Python not running — auto-restart skipped (manual)."
  fi

  sleep 600
done
