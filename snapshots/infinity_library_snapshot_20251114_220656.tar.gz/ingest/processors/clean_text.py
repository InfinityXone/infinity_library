def clean_text(text):
    print("[🧽] Cleaning scraped text...")
    return text.replace("\n", " ").strip()
