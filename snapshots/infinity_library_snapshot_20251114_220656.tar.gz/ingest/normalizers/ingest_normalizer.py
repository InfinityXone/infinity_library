def normalize(data):
    print("[📊] Normalizing data...")
    return data.lower()
