#!/bin/bash
echo "[👁️] Watching system for changes..."
