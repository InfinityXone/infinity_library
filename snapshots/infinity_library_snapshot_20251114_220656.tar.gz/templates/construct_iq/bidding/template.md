# ConstructIQ Template: bidding
