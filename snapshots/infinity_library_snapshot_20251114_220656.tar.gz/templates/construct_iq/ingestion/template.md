# ConstructIQ Template: ingestion
