# ConstructIQ Template: takeoff
