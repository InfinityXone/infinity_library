# Quantum Team Template: strategist
