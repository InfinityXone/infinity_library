# Memory Template: vector
