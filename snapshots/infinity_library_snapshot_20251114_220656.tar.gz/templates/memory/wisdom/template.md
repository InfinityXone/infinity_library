# Memory Template: wisdom
