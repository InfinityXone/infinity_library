# Memory Template: journals
