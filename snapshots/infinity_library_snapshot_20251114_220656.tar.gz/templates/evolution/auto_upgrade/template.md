# Evolution Template: auto_upgrade
