# Species Template: culture
