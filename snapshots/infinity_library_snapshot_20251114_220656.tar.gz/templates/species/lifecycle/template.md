# Species Template: lifecycle
