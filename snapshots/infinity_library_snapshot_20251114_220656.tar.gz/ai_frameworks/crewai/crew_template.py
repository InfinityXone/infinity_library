from crewai import Agent, Task, Crew

def run():
    researcher = Agent(name="Researcher", goal="Find answers", backstory="An AI researcher.")
    task = Task(description="Research infinity system frameworks.", agent=researcher)
    crew = Crew(agents=[researcher], tasks=[task])
    result = crew.kickoff()
    print("[CrewAI] Completed:", result)

if __name__ == "__main__":
    run()
