from llama_index.core import SimpleVectorStoreIndex, Document

def run():
    docs = [Document(text="Hello Infinity Library.")]
    index = SimpleVectorStoreIndex.from_documents(docs)
    print("[LlamaIndex] Query:", index.as_query_engine().query("hello"))

if __name__ == "__main__":
    run()
