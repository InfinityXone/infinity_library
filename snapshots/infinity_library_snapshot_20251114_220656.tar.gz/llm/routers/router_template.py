from groq import Groq
from openai import OpenAI
from mistralai import Mistral
import ollama

class InfinityRouter:
    def __init__(self):
        self.groq = Groq()
        self.openai = OpenAI()
        self.mistral = Mistral()
    
    def route(self, model, prompt):
        if model.startswith("g:"):
            return self.groq.chat.completions.create(model=model[2:], messages=[{"role":"user","content":prompt}])
        if model.startswith("o:"):
            return self.openai.chat.completions.create(model=model[2:], messages=[{"role":"user","content":prompt}])
        if model.startswith("m:"):
            return self.mistral.chat.completions.create(model=model[2:], messages=[{"role":"user","content":prompt}])
        if model.startswith("l:"):
            return ollama.chat(model=model[2:], messages=[{"role":"user","content":prompt}])
        raise ValueError("Unknown model route")
