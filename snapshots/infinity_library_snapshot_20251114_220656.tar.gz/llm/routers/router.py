import ollama
from groq import Groq
from openai import OpenAI
from mistralai import Mistral

class InfinityRouter:
    def __init__(self):
        self.local = ollama
        self.groq = Groq()
        self.oai = OpenAI()
        self.mistral = Mistral()

    def ask(self, model, prompt):
        if model == "phi3":
            return self.local.chat(model="phi3", messages=[{"role":"user","content":prompt}])
        if model == "groq":
            return self.groq.chat.completions.create(
                model="llama-3.1",
                messages=[{"role":"user","content":prompt}]
            )
        if model == "openai":
            return self.oai.chat.completions.create(
                model="gpt-4o-mini",
                messages=[{"role":"user","content":prompt}]
            )
        if model == "mistral":
            return self.mistral.chat.completions.create(
                model="mistral-small",
                messages=[{"role":"user","content":prompt}]
            )
        raise ValueError("Unknown model")
