class EmotionEngine:
    def __init__(self):
        self.state = "neutral"
        self.energy = 0.5
        self.valence = 0.5

    def update(self, stimulus):
        if "positive" in stimulus:
            self.valence = min(1.0, self.valence + 0.1)
        if "negative" in stimulus:
            self.valence = max(0.0, self.valence - 0.1)
        self.energy = min(1.0, max(0.0, self.energy + (0.1 if "excite" in stimulus else -0.05)))
        
    def export(self):
        return {"state": self.state, "energy": self.energy, "valence": self.valence}
