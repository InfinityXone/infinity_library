class BehaviorEngine:
    def act(self, intent):
        if intent == "proceed":
            return {"action": "continue", "success": True}
        return {"action": "idle", "success": False}
