from infinity_library.agents.personas.persona_template import Persona
from infinity_library.agents.emotional_states.emotion_engine import EmotionEngine
from infinity_library.agents.dream_patterns.dream_engine import DreamEngine
from infinity_library.agents.cognitive_maps.cognition import CognitionEngine
from infinity_library.agents.behaviors.behavior_engine import BehaviorEngine
from infinity_library.agents.actions.action_engine import ActionEngine
from infinity_library.agents.memory_hooks.memory_hook import MemoryHook

class Agent:
    def __init__(self, persona):
        self.persona = persona
        self.emotion = EmotionEngine()
        self.dreams = DreamEngine()
        self.cognition = CognitionEngine()
        self.behavior = BehaviorEngine()
        self.actions = ActionEngine()
        self.memory = MemoryHook([])

    def cycle(self, input_text):
        self.emotion.update(input_text)
        reasoning = self.cognition.reason(input_text, self.memory.memory)
        behavior = self.behavior.act(reasoning["decision"])
        result = self.actions.execute(behavior["action"])
        self.memory.record("cycle", {"input": input_text, "result": result})
        return {
            "persona": self.persona.describe(),
            "emotion": self.emotion.export(),
            "reasoning": reasoning,
            "behavior": behavior,
            "result": result
        }
