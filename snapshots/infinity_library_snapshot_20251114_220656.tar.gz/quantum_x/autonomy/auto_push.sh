#!/bin/bash
cd ~/your_project
git add .
git commit -m "Quantum X auto-build"
git push origin main
echo "[🚀 Quantum X] Auto-push complete."
