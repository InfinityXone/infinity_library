# Quantum X Backend Builder
# Auto-generates FastAPI microservices

import os

def build_backend(name, out):
    os.makedirs(out, exist_ok=True)
    with open(f"{out}/service.py","w") as f:
        f.write("# Quantum X auto-generated backend service\n")
        f.write("from fastapi import FastAPI\napp = FastAPI()\n")
    print(f"[🛰️ Quantum X] Backend service created: {name}")
